<?php
	$connection = mysqli_connect('localhost', 'root', '', 'testdb')
		or die('Error connection to MySQL server. ' .mysql_error());
?>
